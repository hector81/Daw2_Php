<?php
	$datosPizzeria=(isset($_POST['datosPizzeria']))? $_POST['datosPizzeria']: null;
	$direccion=(isset($datosPizzeria['direccion']))? $datosPizzeria['direccion']: '';
	$nombre=(isset($datosPizzeria['nombre']))? $datosPizzeria['nombre']: '';
	$telefono=(isset($datosPizzeria['telefono']))? $datosPizzeria['telefono']: '';	
	$cantidaMargatiras=(isset($datosPizzeria['cantidaMargatiras']))? $datosPizzeria['cantidaMargatiras']: '';
    
 		  	 $normal=9;
          $grande=10;
	      $familiar=12;
	  	if (isset($_POST['aceptar'])) {
    if (is_array($_POST['ComplementosM']) ? $_POST['datosPizzeria']: null) {
        $selectedd = '';
		$totalPreciomarF='';
        $num_countriess = count($_POST['ComplementosM']);
        $currentt = 0;
        foreach ($_POST['ComplementosM'] as $keyy => $valuee) {
            if ($currentt != $num_countriess-1){
             $selectedd .= $valuee.', ';
			     
            }else
                $selectedd .= $valuee.'.';
			if($valuee=='Normal 9€'){
		$totalPreciomarF=$cantidaMargatiras*$normal;
			}else if($valuee=='Grande 10€'){
             $totalPreciomarF=$cantidaMargatiras*$grande;
			}else if($valuee=='Familiar 12€'){
             $totalPreciomarF=$cantidaMargatiras*$familiar;
			}			
		   $currentt++;
        }
    }
    
}  
//Masa
	  	if (isset($_POST['aceptar'])) {
    if (is_array($_POST['ComplementosM'])) {
        $masa = '';
        $ma = count($_POST['ComplementosM']);
        $cu = 0;
        foreach ($_POST['ComplementosM'] as $key => $value) {
            if ($cu != $ma-1)
                $masa .= $value.'<br> ';
            else
                $masa .= $value.'.';
            $cu++;
        }
    }
    
} 
$enviado=(isset($_POST['aceptar']))? true:false;
    if(empty($nombre) || empty($direccion) || empty($telefono)){
        $correcto=false ;
    }else{
        $correcto=true;
    }

?>



<!--aqui empieza html en el body-->
<!DOCTYPE html>
    <html>

    <head>
        <title>Ejercicio3: Media de precios.</title>
    </head>

    <body>
        <?php
            if($enviado && $correcto){
				echo "Su pedido se ha realizado correctamene. Gracias por visitarnos";
        ?>
		<br>
		<br>
		<table>
		<tr>
		<th colspan="4">Datos de Cliente</th>
		</tr>
			<tr>
		<td><b>Nombre :</b></td>
		<td> <?= $nombre?> </td>
		</tr>
		<tr>
		<td><b>Dirección:</b></td>
		<td> <?= $direccion?> </td>
		</tr>
		<tr>
		<td><b>Telefono:</b></td>
		<td>  <?= $telefono?>  </td>
		</tr>	
		</table>
			 <?php   		
			  echo ('<br/>');
			$nombPizz="";
			$nombPizz2="";
		        	if (isset($_POST['aceptar'])) {
				foreach ($_POST['nombrePizza'] as $key => $value) {				
					
				
					if($value<>'Barbacoa'){
						$nombPizz .= $value;
						
					}else if($value<>'Margarita'){
							$nombPizz2 .= $value;
					}
			 }  } ?>
			 <b>Detalle de Pedido</b><br>
				<b>Nombre de la pizza :</b>  <?=$nombPizz.'<br>'; ?>
						<b> Masa:</b> <?= $masa?><br> 
      <b>Unidades:</b> <?= $cantidaMargatiras?>  <br>  	
       
		<b>Nombre de la pizza :</b>  <?=$nombPizz2.'<br>'; ?>
     
	 
	  <?php   		
			  echo ('<br/>');
			$complmar="";
			$nombPizz2="";
		        	if (isset($_POST['aceptar'])) {
				foreach ($_POST['ComplementosE'] as $key => $value) {				
					$complmar.=$value;
					
				
			 }  } ?>
			 <?=$complmar.'<br>'; ?>
			 
			 
	 

        <?php 
        }else{
               
        ?>
        <!--En action en lugar del mismo nombre del archivo podemos poner una superglobal que se llama lt&?$_SERVER['PHP_SELF']?>-->
        <form name="frm1" action="<?= $_SERVER['PHP_SELF'] ?>" method="post" >
        <fieldset style="width:350px; background-color:Beige" >
		<h4 align="center">Informacio del cliente</h4><br>
		<label><b>Nombre:</label></b>	<br>
            <input type="text" name="datosPizzeria[nombre]" value="<?= $nombre?>" maxlength="20">
        <?php if($enviado && empty($nombre))
            echo "Es un campo obligatorio.";
        ?>
		<br>
		<label><b>Direccion:    </b></label><br>
        <input type="text" name="datosPizzeria[direccion]" value="<?= $direccion?>" maxlength="20">
        
        <?php if($enviado && empty($direccion))
            echo "Es un campo obligatorio.";
        ?>
		<br> 
		<label><b>Tfno Cliente:</b></label><br>
        <input type="text" name="datosPizzeria[telefono]" value="<?= $telefono?>" maxlength="20"  pattern="[0-9]{9}">
        
        <?php if($enviado && empty($telefono))
            echo "Es un campo obligatorio.";
        ?>
		<br> 
		  <label><b>E-mail:</b></label><br>
<input <input name="email " type="text" size="20" >
		</fieldset>
        <br>
<fieldset style="width:350px;background-color:Beige">

	<h4 align="center">Seleccione sus opciones</h4><br>
<table border="1">
<tr>
<td>
<b>Nombre de pizza</b><br>
<input name="nombrePizza[]" type="checkbox" value="Margarita">Margarita<br>
<b>Cantidad</b><br>
<input name="datosPizzeria[cantidaMargatiras]" type="number" value="<?$cantidaMargatiras?>"></td>
<!--Barbacoa-->
<td>
<b>Nombre de pizza</b><br><input name="nombrePizza[]" type="checkbox" value="Barbacoa">Barbacoa <br>
<b>Cantidad</b><br>
<input name="datosPizzeria[canTidadBarbacoa]" type="number" value="<?$canTidadBarbacoa?>"></td>

</tr>
<tr>  

<td>
<!--Tipo-->
<b>Tipo</b><br>
<input name="ComplementosM[]" type="checkbox" value="Normal 9€">Normal 9€ <br>
<input name="ComplementosM[]" type="checkbox" value="Grande 10€">Grande 10€ <br>
<input name="ComplementosM[]" type="checkbox" value="Familiar 12€">Familiar 12€</td>
</tr>

<tr>  
<td>
<!--masa--><b>Tipo de masa</b><br>
<input name="ComplementosMa[]" type="checkbox" value="Fina">Fina <br>
<input name="ComplementosMa[]" type="checkbox" value="Normal">Normal <br></td>
</tr>
<tr> <td>
<!--Extra-->
<b>Extras</b><br>
<input name="ComplementosE[]" type="checkbox" value="Queso">Queso 1€<br>

<input name="ComplementosE[]" type="checkbox" value="Pimiento">Pimiento 1€ <br>


<input name="ComplementosE[]" type="checkbox" value="Cebolla">Cebolla 1€ <br>


<input name="ComplementosE[]" type="checkbox" value="Jamon">Jamon 2€ <br>


<input name="ComplementosE[]" type="checkbox" value="Pollo">Pollo 2€ </td>
</tr>

</table>

</fieldset>

      <input type="submit" name="aceptar"  value="aceptar"> 
	   <input type="submit" name="cancelar" value="cancelar"></form>
      <?php }?>
	  



 
	  
    </body>

</html>