
<?php

    // Variables cliente

    $nombre = isset($_POST[ 'nombre' ]) ? $_POST['nombre'] : null;
    $dir = isset($_POST[ 'dir' ]) ? $_POST['dir'] : null;
    $telefono = isset($_POST[ 'telefono' ]) ? $_POST['telefono'] : null;
    
    // Variables pedido

    $pizza = isset($_POST[ 'pizza' ]) ? $_POST['pizza'] : null;
    $cantidad = isset($_POST[ 'cantidad' ]) ? $_POST['cantidad'] : null;
    $tamaño = isset($_POST[ 'tamaño' ]) ? $_POST['tamaño'] : null;
    $masa = isset($_POST[ 'masa' ]) ? $_POST['masa'] : null;

    $dirAceptar = isset($_POST[ 'dirAceptar' ]) ? $_POST['dirAceptar'] : null;
		
?>


<!DOCTYPE html>
<html>
	<head>
		<title> PizzaNet </title>
		<h1> PizzaNet </h1>
	</head>
    
	<body>
		<form name="input" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
           <fieldset>
               <legend>Datos del cliente</legend>
                <table>
               
                    <tr>
                        <td>
                            * Nombre: <input type="text" value="<?= $nombre ?>" name="nombre" placeholder="Introduce tu nombre">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            * Dirección: <input type="text" value="<?= $dir ?>" name="dir" placeholder="Introduce tu dirección">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            * Teléfono: <input type="text" value="<?= $telefono ?>" name="telefono" pattern="[0-9]{9}" placeholder="Introduce tu teléfono">
                        </td>
                    </tr>
                   </table>
            </fieldset>
            <br>
            <fieldset>
               <legend>Datos del pedido</legend>
            
               <table>

                <tr>
                    <td>
                        Nombre:
                    </td>
                    <td>
                        Cantidad:
                    </td>
                    <td>
                        Tamaño:
                    </td>
                    <td>
                        Masa:
                    </td>
                    
                    <td>
                        Extras:
                    </td>
                </tr>
                
                <tr>
                </tr>
                <tr>
                </tr>
                
           
            
            <?php


    
$var = <<<HTML
<tr>
<td>
<select name="pizza[]">
<option selected>Selecciona una pizza</option>
<option value="margarita">Margarita</option>
<option value="barbacoa">Barbacoa</option>
<option value="4estaciones">4 estaciones</option>
<option value="4quesos">4 quesos</option>
<option value="carbonara">carbonara</option>
<option value="romana">romana</option>
<option value="mediterranea">mediterránea</option>
</select>
</td>
<td>
<input type="number"  name="cantidad[]" value="0" min="0" max="100" >
</td>
<td>
<select name="tamaño[]">
<option selected value="normal">Normal</option>
<option value="grande">Grande</option>
<option value="familiar">Familiar</option>
</select>
</td>
<td>
<select name="masa[]">
<option value="fina">Fina</option>
<option selected value="normal">Normal</option>
</select>
</td>

HTML;
              
              $extra = "extras";    // Variable para el nombre de los extras
              for($i = 0; $i < 7; $i++){
                  $extra = "extras" . $i . "[]";    
                    echo $var;
                  
                    echo "<td>";
                        echo "<input type='checkbox' name='" . $extra . "' value='queso'> Queso" ;
                        echo "<input type='checkbox' name='" . $extra . "' value='pimiento'> Pimiento ";
                        echo "<input type='checkbox' name='" . $extra . "' value='cebolla'> Cebolla"; 
                        echo "<input type='checkbox' name='" . $extra . "' value='jamon'> Jamón"; 
                        echo "<input type='checkbox' name='" . $extra . "' value='pollo'> Pollo"; 
                    echo "</td>";
                    echo "</tr>";
                  
              }
               
            ?> 
            </table>
            </fieldset>
            
            <br>
            
            <input type="submit" value="Enviar pedido" />
            <br><br>
        
            <?php
            
                if(isset($_POST[ 'dirAceptar' ])){
                    echo "<br><br>";
                    echo "Gracias por su compra.";
                    echo "<br>";
                    echo "Le llevaremos su pedido a " . $dirAceptar . " en 15 minutos."; 
                }
            
                if(isset($_POST[ 'dirCancelar' ])){
                    echo "Pedido cancelado";
                }
                  
                // Datos del cliente
          
                if($nombre != null and $dir != null and $telefono != null){
                    echo "Cliente: " . $nombre . "</br>";
                    echo "Dirección: " . $dir . "</br>";
                    echo "Teléfono: " . $telefono . "</br>";
                    echo "</br>";
                }
               
            
                // Datos del pedido
                
                $precioTamaño = ["normal" => 5, "grande" => 10, "familiar" => 15];      // precio de las pizzas por tamaño
                $precioExtras = ["queso" => 2, "pimiento" => 3, "cebolla" => 4, "jamon" => 5, "pollo" => 6];    // precio de cada extra
                
                $precioIndividual = 0;
                $precioTotal = 0;
        
            
                for($i = 0; $i < sizeof($pizza); $i++){
                    if($pizza[$i] != "Selecciona una pizza" and $cantidad[$i] > 0){
                        
                        echo $cantidad[$i] . " pizzas " . $pizza[$i] . " tamaño " . $tamaño[$i] . " con masa " . $masa[$i];
                       
                        $extras = isset($_POST[ 'extras' . $i ]) ? $_POST['extras' . $i] : null;
                        
                        for($j = 0; $j < sizeof($extras); $j++){      
                                echo(" con extras de " . $extras[$j] . " ");  
                                $precioIndividual = $precioIndividual + $precioExtras[$extras[$j]];
                        }                       
                        
                        $precioIndividual = $precioIndividual + $precioTamaño[$tamaño[$i]];
                        $precioIndividual = $precioIndividual * $cantidad[$i]; 
                        
                        $precioTotal = $precioTotal + $precioIndividual;
                        
                        echo "</br>";
                        echo "Precio: " . $precioIndividual . " €";
                        echo "</br></br>";
                        
                        $precioIndividual = 0;
                  
                    }        
                
                        
                }
            
                if($precioTotal > 0){
                    echo "Precio total: " . $precioTotal . " €";                   
                    echo "<br><br>";
                    
                }
                                             
            ?>
            
		</form>
		
		<!-- Botones aceptar y cancelar !-->
		<?php if($precioTotal > 0){ ?>
		    <form name="input" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                <input type="submit" value="Aceptar" />  
                <input type="text" hidden="hidden" value="<?= $dir ?>" name="dirAceptar">
            </form>
            <br>
            <form name="input" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                <input type="submit" value="Cancelar" />
                <input type="text" hidden="hidden" value="Pedido cancelado" name="dirCancelar">
            </form>      
            
        <?php } ?>      
                  
	</body>
        
</html>
