<?php 
$totalLineas = 7;
$opcionesMenu=[
		'tipo' =>[
		        'margarita'=>6, 
		        'barbacoa'=>8, 
		        'estaciones'=>6, 
		        'quesos'=>7, 
		        'carbonara'=>7, 
		        'romana'=>6, 
		        'mediterranea'=>6, 
		],
		'tamaño'=>[
		          'normal'=>0, 
		          'grande'=>3, 
		          'familiar'=>5, 
                ], 
		   
		'masa'=>[
                    'fina'=>0, 
                    'gorda'=>0
                ] ,
		   
		'extras'=>[
                         'queso'=>1, 
		          'pimiento'=>1, 
		          'cebolla'=>1, 
		          'jamon'=>2, 
		          'pollo'=>2, 
		],

		'cantidad'=>0
];

/*
$pedido=[
		'cliente' =>['nombre'=>'',
                        'direccion'=>'',
                        'telefono'=> '', 
                        'email'=>''
		],
		'lineasPedido'=> [['tipo', 'masa', 'tamaño', 'extras', 'cantidad']    
            	]
];
*/

$motivo=['cambioOpinion', 'precioCaro','masTarde'];

$pedido=(isset($_POST['pedido']))? $_POST[ 'pedido']: null; 
$direccion=(isset($pedido['cliente']['direccion']))? $pedido['cliente']['direccion']:null;
$enviado=(isset($_POST[ 'anadir']))? true:false; 
$aceptado=(isset($_POST['aceptado']))? $_POST['aceptado']:null;
$cancelado=(isset($_POST['cancelado']))? $_POST['cancelado']:null;
$motivo=(isset($_POST['motivo']))? $_POST['motivo']: null;
$ok=(isset($_POST['ok']))? $_POST['ok']: null;
$correcto=true;

//Validaciones al enviar
if($enviado){

	//si hay campos vacíos
	if(empty($pedido['cliente']['nombre']) || empty($pedido['cliente']['direccion']) || empty($pedido['cliente']['telefono']) || 		empty($pedido['cliente']['email'])){
	$correcto=false;
	?><font color="red">Los campos con * son obligatorios.<br></font><?php
	}
	if($pedido['lineasPedido'][0]['cantidad']== 0){
	$correcto=false;
	?><font color="red">Para enviar el pedido debe haber al menos una pizza.<br></font><?php
	}

	//Válida el teléfono (aunque al tratarse de un formato tan variable es mejor no hacerlo, en este ejercicio lo valido como prueba)
	if($pedido['cliente']['telefono'] <900000000 ||$pedido['cliente']['telefono']>999999999 || $pedido['cliente']['telefono']<600000000){
	$correcto=false;
	?><font color="green">El número de teléfono debe ser un formato válido: 9 dígitos empezando por 9 o 6.</font><?php
	}
}

//Funciones
function subtotal($linea, $opcionesMenu){
    $subtotal=0;
    foreach($linea as $nombreCampo => $valorCampo){
        if(is_array($valorCampo) == true){
            foreach($valorCampo as $extra){
                $subtotal += $opcionesMenu[$nombreCampo][$extra];
            }
        } else {
            $subtotal += $opcionesMenu[$nombreCampo][$valorCampo];
        }
    }
    return $subtotal * (int) $linea['cantidad'];
}

function total($lineasPedido,$opcionesMenu){
    $total=0;
    foreach($lineasPedido as $linea){
        
        $total+=subtotal($linea,$opcionesMenu);
    }
    
    return $total;
}
?>

<!DOCTYPE HTML>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="PizzaNet" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ejercicio4:Formulario PizzaNet</title>
</head>


<body>
   
   <?php if($enviado && $correcto){ ?>
   <!---Si el usuario envia el pedido, muestra factura-->
    <form name="input" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
		<table>
			<tr>
				<th colspan="4">PEDIDO</th>
			</tr>
				<tr>
				<td colspan="4">DATOS:</td>
			</tr>
			<tr>
				<td><?= $pedido['cliente']['nombre'] ?></td>
				<td><input type="hidden" name="pedido[cliente][direccion]" value="<?= $direccion?>"><?= $direccion?></td>
				<td><?= $pedido['cliente']['telefono'] ?></td>
				<td><?= $pedido['cliente']['email'] ?></td>
			</tr>
			<tr>
				<td colspan="4">PIZZAS:</td>
			</tr>
			<?php foreach($pedido['lineasPedido'] as $index=>$linea){
			?><tr><?php
			?><td colspan="2"><?
                    if($linea['cantidad'] > 0){
                        foreach($linea as $nombreCampo => $valorCampo){
			
                            if(is_array($valorCampo) == true){
                                echo "Extra:";
                                foreach($valorCampo as $extra){
					
                                    echo ucfirst($extra). ",\n";
                                }
                            } else {
                                echo ucfirst($nombreCampo) .": ". ucfirst($valorCampo). " |\n";
                            }
                        }
			?>
			</td><td> <?php
                        echo "SUBTOTAL :" . subtotal($linea,$opcionesMenu). " €";
                    }
                  ?></td>  
		</tr>
               <?php }?>
		<tr><td> <?php
                echo "TOTAL: ".total($pedido['lineasPedido'], $opcionesMenu). " €";
             ?>
			</td> 
        
		</tr>
    </table>
	<!---Una vez mostrada la factura el cliente puede aceptar o cancelar el pedido-->
	<input type="submit" name="aceptado" value="Aceptar">
	<input type="submit" name="cancelado" value="Cancelar">
         
 </form>    

<?php}else if($aceptado){ ?>
 <p>Gracias por pedir en PizzaNet,tu repartidor Gonzalo llevará tu pedido a la dirección <?= $direccion ?> en un plazo de 30 minutos.</p>


<?php}else if($cancelado){  ?>
	<form name="input" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
	 	<p>Lamentamos que finalmente no desees tu pedido. <br>Por favor indicanos porque has decidido cancelar el pedido, para futuras referencias:<br></p>
		<input name="motivo[cambioOpinion]" type="checkbox" value="<?= $motivo['cambioOpinion']?>" >He cambiado de opinión.<br>
		<input name="motivo[precioCaro]" type="checkbox" value="<?= $motivo['precioCaro']?>" >Es más caro de lo que pensaba.<br>
		<input name="motivo[masTarde]" type="checkbox" value="<?= $motivo['masTarde']?>" >Pediré más tarde.<br>
		<input type="submit" name="ok" value="Enviar"> 
	</form>

<?php}else if($ok){  ?>
	<p>Gracias, hemos guardado tu opinión.</p>
<?php}else{ ?>

    <form name="input" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
<!-- datos cliente-->
     <fieldset>
        <legend>Datos cliente</legend><br>  
			<label>Nombre y apellidos*: </label>
				<input type="text" name="pedido[cliente][nombre]" value="<?= $pedido['cliente']['nombre'] ?>" maxlength="20">
			<label>Dirección*: </label>
				<input type="text" name="pedido[cliente][direccion]" value="<?= $direccion ?>" maxlength="20">
			<label>Teléfono*: </label>
				<input type="tel" name="pedido[cliente][telefono]" value="<?= $pedido['cliente']['telefono'] ?>" maxlength="20">
			<label>email*: </label>
				<input type="email" name="pedido[cliente][email]" value="<?= $pedido['cliente']['email'] ?>" maxlength="20">
     </fieldset>
<!--datos pizzas-->    
        <legend>Mi pedido:</legend><br>  
        <?php
            for($i=0;$i<$totalLineas;$i++){      
        ?>   
        <fieldset>
            <label for="tipo">Tipo: </label>
                <select id="tipo" name="pedido[lineasPedido][<?= $i ?>][tipo]" >
                    <option value="margarita" >Margarita 6€</option>
                    <option value="barbacoa" >Barbacoa 8€</option>
                    <option value="estaciones" >4Estaciones 6€</option>
                    <option value="quesos" >4Quesos 7€</option>
                    <option value="carbonara" >Carbonara 7€</option>
                    <option value="romana">Romana 6€</option>
                    <option value="mediterranea">Mediterranea 6€</option>
                </select> 
            <label for="masa">Masa: </label>
				<select id="masa" name="pedido[lineasPedido][<?= $i ?>][masa]">
                   <option value="fina">Fina</option>
                   <option value="gorda">Gorda</option>       
				</select>

            <label for="tamaño">Tamaño: </label>
                <select id="tamaño" name="pedido[lineasPedido][<?= $i ?>][tamaño]">
                    <option value="normal">Normal</option>
                    <option value="grande">Grande +3€ </option>
                    <option value="familiar">Familiar +5€</option>  
                </select>

			<label for="extras">Extras: </label>
			   <select id="extras" name="pedido[lineasPedido][<?= $i ?>][extras][]" multiple="multiple">
				   <option value="queso">Queso</option>
					<option  value="pimiento">Pimiento</option>
					<option value="cebolla">Cebolla</option>
					<option  value="jamon">Jamon</option>
					<option value="pollo">Pollo</option>
			   </select>

			<label>Cantidad:</label>
                <input type="number" name="pedido[lineasPedido][<?= $i ?>][cantidad]" value="0" size="1" min="0" max="20"><br>
        </fieldset>
        <?php } ?> 
            <input type="submit" name="anadir" value="Añadir al pedido">
			
    <?php} ?>  
  
</body>


</html>
