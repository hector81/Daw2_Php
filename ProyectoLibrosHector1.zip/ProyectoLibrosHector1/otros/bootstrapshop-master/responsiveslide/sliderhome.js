
        $(function () {
           $("#slider1").responsiveSlides({
            auto: true,
            pager: true,
            nav: true,
            speed: 500,
            maxwidth: 850,
            width: 850,
            namespace: "centered-btns"
          });
        });
